package test.java;

import com.inflectra.spiratest.addons.junitextension.SpiraTestCase;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import static org.junit.jupiter.api.Assertions.*;

class AddNewRecordTest extends BankTestBase {

    @Test
    @SpiraTestCase(testCaseId = 1)
    public void testAddNewRecordNormalCase() {
        simulateInput("John Doe\n12345678\n1234\n500\n");
        bank.addNewRecord();

        assertEquals(1, bank.AL.size());
        Account account = bank.AL.get(0);
        assertAccountDetails(account, "John Doe", 12345678, "1234", 1500);
    }

    @Test
    @SpiraTestCase(testCaseId = 2)
    public void testAddNewRecordZeroAdditionalAmount() {
        simulateInput("Jane Doe\n87654321\n4321\n0\n");
        bank.addNewRecord();

        assertEquals(1, bank.AL.size());
        Account account = bank.AL.get(0);
        assertAccountDetails(account, "Jane Doe", 87654321, "4321", 1000);
    }

    @Test
    @SpiraTestCase(testCaseId = 3)
    public void testAddNewRecordNegativeAmount() {
        simulateInput("Bob Smith\n11223344\n5678\n-200\n");
        bank.addNewRecord();

        assertEquals(1, bank.AL.size());
        Account account = bank.AL.get(0);
        assertAccountDetails(account, "Bob Smith", 11223344, "5678", 800);
    }

    @Test
    @SpiraTestCase(testCaseId = 4)
    public void testAddMultipleAccounts() {
        simulateInput("Alice\n11111111\n1111\n100\n");
        bank.addNewRecord();
        simulateInput("Bob\n22222222\n2222\n200\n");
        bank.addNewRecord();

        assertEquals(2, bank.AL.size());
        assertAccountDetails(bank.AL.get(0), "Alice", 11111111, "1111", 1100);
        assertAccountDetails(bank.AL.get(1), "Bob", 22222222, "2222", 1200);
    }

    @Test
    @SpiraTestCase(testCaseId = 5)
    public void testAddNewRecordInvalidAccountNumber() {
        simulateInput("Invalid\n123\n1234\n100\n");
        bank.addNewRecord();

        // Assuming the method doesn't validate input, this will still add the account
        // In a real-world scenario, you might want to add input validation
        assertEquals(1, bank.AL.size());
        Account account = bank.AL.get(0);
        assertAccountDetails(account, "Invalid", 123, "1234", 1100);
    }
}