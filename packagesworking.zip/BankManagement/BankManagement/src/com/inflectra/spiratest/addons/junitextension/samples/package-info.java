/**
 * Provides examples on how to use JUnit 4.0+ with SpiraTest v1.2+
 *
 * @since 4.0
 */
package com.inflectra.spiratest.addons.junitextension.samples;