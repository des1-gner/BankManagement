@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.inflectra.com/SpiraTest/Services/v3.0/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.inflectra.spiratest.addons.junitextension.soap;
